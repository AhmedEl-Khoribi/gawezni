<?php $__env->startSection('content'); ?>

<form method="POST" action="/admin/updateUser/<?php echo e($user->id); ?>" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

  <input type="hidden" name="_method" value="PATCH">
<div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">Main Information</h3>
            </div>
	<div class="form-group has-success">
	  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> Username</label>
	  <input type="text" class="form-control" name="username" id="inputSuccess" value="<?php echo e($user->username); ?>">
	  <span class="help-block">Must Choose a unique Username</span>
	</div>
	<div class="form-group">
      <label>Email</label>
      <input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>">
    </div>
	<div class="box-body">
      <div class="row">
        <div class="col-xs-3">
        <label>Phone</label>
          <input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>">
        </div>
        <div class="col-xs-4">
        <label>Career Field</label>
          <input type="text" name="career_field" class="form-control" value="<?php echo e($user->career_field); ?>">
        </div>
        <div class="col-xs-5">
        <label>Job</label>
          <input type="text" name="job" class="form-control" value="<?php echo e($user->job); ?>">
        </div>
      </div>
    </div>
    <div class="box-body">
      <div class="row">
        <div class="col-xs-3">
        <div class="form-group">
          <label>Education</label>
          <select class="form-control" name="education">
            <option value="medium_school" <?php if($user->education === "medium_school"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Medium School</option>
            <option value="high_school" <?php if($user->education === "high_school"): ?> <?php echo e('selected'); ?> <?php endif; ?>>High School</option>
            <option value="university" <?php if($user->education === "university"): ?> <?php echo e('selected'); ?> <?php endif; ?>>University</option>
            <option value="PHD" <?php if($user->education === "PHD"): ?> <?php echo e('selected'); ?> <?php endif; ?>>PHD</option>
            <option value="self_study" <?php if($user->education === "self_study"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Self Study</option>
          </select>
        </div>
        </div>
        <div class="col-xs-4">
        <label>Salary ( <?php echo e($user->city->country->currency); ?> )</label>
          <input type="text" name="salary" class="form-control" value="<?php echo e($user->salary); ?>">
        </div>
        <div class="col-xs-5">
        <div class="form-group">
          <label>Finantial Status</label>
          <select class="form-control" name="financial_status">
            <option value="poor" <?php if($user->financial_status === "poor"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Poor</option>
            <option value="lower_than_medium" <?php if($user->financial_status === "lower_than_medium"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Lower Than Medium</option>
            <option value="medium" <?php if($user->financial_status === "medium"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Medium</option>
            <option value="more_than_medium" <?php if($user->financial_status === "more_than_medium"): ?> <?php echo e('selected'); ?> <?php endif; ?>>More Than Medium</option>
            <option value="good" <?php if($user->financial_status === "good"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Good</option>
            <option value="mastora" <?php if($user->financial_status === "mastora"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Mastoora w ell7</option>
            <option value="rich" <?php if($user->financial_status === "rich"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Rich</option>
          </select>
        </div>
      </div>
    </div>
   </div>
   <div class="box-body">
      <div class="row">
         <div class="col-xs-3">
        	<label>First Name</label>
          <input type="text" name="fname" class="form-control" value="<?php echo e($user->fname); ?>">
        </div>
        <div class="col-xs-4">
        <label>Last Name</label>
          <input type="text" name="lname" class="form-control" value="<?php echo e($user->lname); ?>">
        </div>
        <div class="col-xs-5">
        <div class="form-group">
          <label>Gender</label>
          <select class="form-control" name="gender" id="gender">
            <option value="male" <?php if($user->gender === "male"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Male</option>
            <option value="female" <?php if($user->gender === "female"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Female</option>
          </select>
        </div>
      </div>
    </div>
   </div>
   <div class="row">
         <div class="col-xs-3">
   <div class="form-group">
    <label>Date Of Birth:</label>
    <div class="input-group date">
      <div class="input-group-addon">
        <i class="fa fa-calendar"></i>
      </div>
      <input type="text" name="dob" class="form-control pull-right" id="datepicker" value="<?php echo e($user->dob); ?>">
    </div>
	</div>
	</div>
	<div class="col-xs-4">
    <div class="form-group">
      <label>Country</label>
      <select class="form-control" id="country">
      	<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($country->id); ?>" <?php if($user->city->country->name === $country->name): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($country->name); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    </div>
    <div class="col-xs-4">
    <div class="form-group" style="display: none;" id="cityDisplay">
      <label>City</label>
      <select class="form-control" id="city" name="city_id">
        <option value="1">choose City</option>
      </select>
    </div>
    </div>
  </div>
</div>
<div class="box box-success">
	<div class="box-header with-border">
        <h3 class="box-title">Social Infromation</h3>
    </div>
<div class="box-body">
      <div class="row">
        <div class="col-xs-3">
        <div class="form-group">
          <label>Social Status</label>
          <select class="form-control" name="social_status" id="social_single">
            <option value="single" <?php if($user->social_status === "single"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Single</option>
            <option value="married" <?php if($user->social_status === "married"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Married</option>
            <option value="divorced" <?php if($user->social_status === "divorced"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Divorced</option>
            <option value="willow" <?php if($user->social_status === "willow"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Willow</option>
          </select>
        </div>
        </div>
        <?php if($user->gender === 'male'): ?>
        <div class="col-xs-3" id="marraige12">
        <div class="form-group">
          <label>Number Of Wives</label>
          <select class="form-control" name="marraige_status">
            <option value="first" <?php if($user->marraige_status === "first"): ?> <?php echo e('selected'); ?> <?php endif; ?>>First</option>
            <option value="second" <?php if($user->marraige_status === "second"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Second</option>
            <option value="third" <?php if($user->marraige_status === "third"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Third</option>
            <option value="fourth" <?php if($user->marraige_status === "fourth"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Fourth</option>
          </select>
        </div>
      </div>
      <?php endif; ?>
      <?php if($user->social_status === 'married' || $user->social_status === 'divorced'): ?>
      <div class="col-xs-4" id="numberChild">
        <label>Number Of Children</label>
          <input type="text" name="children_number" class="form-control" value="<?php echo e($user->children_number); ?>">
      </div>
      <?php endif; ?>
    </div>
   </div>
   <div class="box box-info">
    <div class="box-header">
      <h3 class="box-title">About User
        <small>Describtion about user</small>
      </h3>
      <div class="pull-right box-tools">
        <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip"
                title="Collapse">
          <i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-danger btn-sm" data-widget="remove" data-toggle="tooltip"
                title="Remove">
          <i class="fa fa-times"></i></button>
      </div>
    </div>
    <div class="box-body pad">
            <textarea id="editor1" name="main_description" rows="10" cols="80">
                  <?php echo e($user->main_description); ?>

            </textarea>
    </div>
  </div>
   <div class="box box-info">
    <div class="box-header">
      <h3 class="box-title">Other Person Information
        <small>Your partner description</small>
      </h3>
      <div class="pull-right box-tools">
        <button type="button" class="btn btn-default btn-sm" data-widget="collapse" data-toggle="tooltip"
                title="Collapse">
          <i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-danger btn-sm" data-widget="remove" data-toggle="tooltip"
                title="Remove">
          <i class="fa fa-times"></i></button>
      </div>
    </div>
    <div class="box-body pad">
        <textarea class="textarea" name="other_person_description"
                  style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
                  	<?php echo e($user->other_person_description); ?>

        </textarea>
    </div>
  </div>
  <div class="box box-warning">
	<div class="box-header with-border">
	    <h3 class="box-title">Shape & Body</h3>
  </div>
  <div class="box-body">
      <div class="row">
         <div class="col-xs-3">
        	<label>Weight</label>
          <input type="text" name="weight" class="form-control" value="<?php echo e($user->weight); ?>">
        </div>
        <div class="col-xs-4">
        <label>Height</label>
          <input type="text" name="height" class="form-control" value="<?php echo e($user->height); ?>">
        </div>
        <div class="col-xs-5">
        <div class="form-group">
          <label>Physique</label>
          <select class="form-control" name="physique">
            <option value="thin" <?php if($user->physique === "thin"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Thin</option>
            <option value="medium_thin" <?php if($user->physique === "medium_thin"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Moderate thin
            </option>
            <option value="sporty" <?php if($user->physique === "sporty"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Sporty</option>
            <option value="fat" <?php if($user->physique === "fat"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Fat</option>
			      <option value="huge" <?php if($user->physique === "huge"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Huge</option>
          </select>
        </div>
      </div>
    </div>
   </div>
   <div class="form-group">
	  <label>Skin Color</label>
	  <select class="form-control" name="skin_color">
	    <option value="white" <?php if($user->skin_color === "white"): ?> <?php echo e('selected'); ?> <?php endif; ?>>White</option>
	    <option value="black" <?php if($user->skin_color === "black"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Black
	    </option>
	    <option value="dark_brown" <?php if($user->skin_color === "dark_brown"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Dark Brown</option>
	    <option value="brown" <?php if($user->skin_color === "brown"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Brown</option>
		<option value="7enty_dark" <?php if($user->skin_color === "7enty_dark"): ?> <?php echo e('selected'); ?> <?php endif; ?>>حنطي غامق</option>
		<option value="7enty_white" <?php if($user->skin_color === "7enty_white"): ?> <?php echo e('selected'); ?> <?php endif; ?>>ححنطي  فاتح
		</option>
	  </select>
	</div>
</div>
<div class="form-group has-error">
  <label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i> Health Issues</label>
  <input type="text" name="health_details" class="form-control" id="inputError" value="<?php echo e($user->health_details); ?>">
  <span class="help-block">all about users health</span>
</div>
<div class="row">
      <div class="col-xs-4">  
        <h5>Old Site Fivicon</h5>
      <img src="/files/users/<?php echo e($user->image); ?>" width="215">
      </div>
      <div class="col-xs-8">  
        <label>Upload new site Fivicon</label>
        <input type="file" name="image" class="form-control">
      </div>
  </div>
<div class="box-footer">
<button type="submit" class="btn btn-success btn-block btn-flat">Edit User's Info</button>
</div>
</form>
<?php if(count($errors)): ?>
<div class="alert alert-danger">
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>