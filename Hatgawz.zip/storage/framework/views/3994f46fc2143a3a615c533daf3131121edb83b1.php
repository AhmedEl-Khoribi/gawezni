
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-ban"></i> Error!</h4>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p>* <?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
            <!-- Modal -->
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-check"></i> Successful</h4>
                <?php if(Session::has('message')): ?>
                     <p><?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>
            </div>

            <?php endif; ?>
            <?php if(isset($country)): ?>
                <form action="<?php echo e(route('country.store')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="box box-danger">
                        <div class="box-header">
                            <h3 class="box-title">New Country</h3>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <label>Country Name</label>
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-pencil"></i>
                                    </div>
                                    <input type="text" class="form-control" name="name" placeholder="Country Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>currency</label>
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-money"></i>
                                    </div>
                                    <input type="text" class="form-control" name="currency" placeholder="Currency">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <button type="submit" class="btn btn-block btn-primary btn-lg">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
            <?php if(isset($city)): ?>
                    <form action="<?php echo e(route('city.store')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="box box-danger">
                            <div class="box-header">
                                <h3 class="box-title">New City</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group">
                                    <label>City Name</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-pencil"></i>
                                        </div>
                                        <input type="text" class="form-control" name="name" placeholder="City Name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Choose Country</label>
                                    <select class="form-control" name="country_id">
                                        <option  value="">Please Choose Country</option>
                                        <?php $__currentLoopData = $cityCountry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <button type="submit" class="btn btn-block btn-primary btn-lg">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>