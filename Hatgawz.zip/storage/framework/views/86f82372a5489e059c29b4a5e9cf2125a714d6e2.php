<footer class="footer-distributed">

    <div class="footer-left">
        <p class="footer-company-about" style="direction: rtl;text-align: right" >
            <span style="direction: rtl"> هتجوز </span>
            موقع تعارف وتواصل عريق يضع الوطن العربي والعالم بين يديك من خلال الدردشة والمراسلة والمحادثة والشات للقاء شريك العمر والارتباط بالنصف الآخر و فارس الأحلام. 				</p>
    </div>
    <div class="footer-center" style="direction: rtl;text-align: center" >
        <div>
            <a href="/client/contact">
            <i class="fa fa-envelope"></i>
            <p>رسائل الادارة</p>
            </a>
        </div>
        <div>
            <a href="/client/nsay7">
                <i class="fa fa-check"></i>
                <p>نصائح واقتراحات</p>
            </a>
        </div>
        <div>
            <a href="/client/faq">
            <i class="fa fa-question"></i>
            <p>الاسئله المتداولة</p>
            </a>
        </div>
    </div>

    <div class="footer-right">
        <h3><img src="/visitor/images/logo-man.png"></h3>

    </div>
</footer>
<footer>
    <div class="copy">
        <p>&copy; 2018 All Rights Reserved | Design by <a href="http://gtsaw.com/">gtsaw</a> </p>
    </div>
</footer>