<?php $__env->startSection('content'); ?>
<?php
  $do = (isset($_GET['do'])) ? $_GET['do'] : 'blocked' ;
?>
<style>
    .exportExcel{
  padding: 5px;
  border: 1px solid grey;
  margin: 5px;
  cursor: pointer;
}
</style>

<div class="box">
            <div class="box-header">
  <h3 class="box-title">Data Table For Not Approved Users</h3>
</div>
            <div class="box-body">
              <table id="example3" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Full Name</th>
                  <th>Email</th>
                  <th>Phone Number</th>
                  <th>MemberShip</th>
                  <th>Registered At</th>
                </tr>
                </thead>
                <tbody>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($user->id); ?></td>
                  <td><?php echo e($user->username); ?></td>
                  <td><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></td>
                  <td><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->phone); ?></td>
                  <td><?php echo e($user->member_ship); ?></td>
                  <td><?php echo e($user->created_at); ?></td>
                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>