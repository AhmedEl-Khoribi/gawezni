<!DOCTYPE HTML>
<html>
<head>
<title>هتجوز </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Day Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="/visitor/css/bootstrap.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Cairo" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
<link href="//cdn.datatables.net/1.10.18/css/jquery.dataTables.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!--Custom-Theme-files-->
	<link href="/visitor/css/style.css" rel="stylesheet" type="text/css" />
<style>
	
	body{
  background-color:#ccc;
  font-family: 'Montserrat', sans-serif;
}
.page-header{
  background-color:#27aae1;
  height:100px;
  margin:0px;
}
.profile-container{
  width:40%;
  margin:auto;
  background-color:#fff;
  padding:30px;
  margin-top:-50px;
  height:auto;direction: rtl
}
.user-name{
  color:#0e2f44;
  font-weight:bold;
	text-align: center
}
.user-mail{
  color:#858585;
	text-align: center
}
.user-company{
  font-weight:bold;
  color:#f067ae;
	text-align: center
}
	.more-info{
  background-color:#e5e5e5;
  border-bottom:#ccc 1px solid ;
	direction: rtl;
		text-align: center
}
	.more-info h5{
		color: #27aae1;
		font-weight: 200
	}
	.todo-links{
  padding:10px;
  border-bottom:1px solid #ccc;

}
.todo-links a i{
  margin-right:20px;
}
.todo-links a{
  color:#000;
  font-size:16px;
}

.alert {
    padding: 20px;
    background-color: #f44336;
    color: white;
}

.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: #ff9800;}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}
.closebtn:hover {
    color: black;
}
</style>
</head>
    <?php echo $__env->make('visitor.template.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<br>
	<br>
	


	<!-- Profile Page , Modal -->
<div class="page-header"></div>
<div class="profile-container" id="profile">
    <?php if(Auth::guard('client')->check()): ?>
  <input type="hidden" name="client_id" value="<?php echo e($user->id); ?>" id="client_id">
    <?php endif; ?>
  <div class="row">
  <div class="col-md-4">
    <img src="<?php echo e(asset('files/users/' . $user->image )); ?>" class="img-responsive" width="100" height="100" />
  </div>

  <div class="col-md-8 profile-info" >
    <?php if($flash = session('message')): ?>
          <div class="alert success">
              <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
              <b><?php echo e($flash); ?></b>
          </div>
      <?php endif; ?>
      <?php if($flash = session('deleted')): ?>
          <div class="alert">
              <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
              <b><?php echo e($flash); ?></b>
          </div>
      <?php endif; ?>
    <h4 class="user-name"><?php echo e($user->fname . ' ' . $user->lname); ?></h4>
    <h5 class="user-mail"><i><?php echo e($user->geneder); ?> </i></h5>
    <h5 class="user-company"><?php echo e(\App\Country::find($user->city->country_id)->name . ' , ' . $user->city->name); ?></h5>
    <hr>
    <div class="row" style="    margin-right: -183px;">
        <div class="col-md-4" >
      <a href="/client/block/<?php echo e($user->id); ?>"><button  class="btn btn-danger"><i class="fa fa-ban"></i>حظر </button></a>
    </div>
    <?php if(Auth::guard('client')->check()): ?>
      <?php
        $is_liked = \App\Friend::where('client_id', \Auth::guard('client')->user()->id)->where('friend_id', $user->id)->exists();
      ?>
      <?php if($is_liked === false): ?>
      <div class="col-md-4" >
        <button  class="btn btn-success friend_request"><span id="pending<?php echo e($user->id); ?>"><i class="fa fa-heart" style="color: red"></i> اعجاب</span></button>
        <input type="hidden" name="friend_id" value="<?php echo e($user->id); ?>" class="friend_id">
      </div>
      <?php else: ?>
      <div class="col-md-4" >
       <button  class="btn btn-success friend_request"><span id="pending<?php echo e($user->id); ?>"><span id="added"><i class="fa fa-clock-o" style="color: red"></i> انتظر تأكيد الطلب</span></span></button>
        <input type="hidden" name="friend_id" value="<?php echo e($user->id); ?>" class="friend_id">
      </div>
      <?php endif; ?>
      <?php endif; ?>
    <div class="col-md-4" >
      <a href="<?php echo e(url('/client/message/'. $user->id)); ?>"><button  class="btn btn-warning"><i class="fa fa-envelope"></i>ارسال رسالة </button></a>
    </div>
  </div>
  <hr>

  </div>
</div>
  <br/><br/>
  
  
    
    
  
    
      
    

  
  
   <div class="row more-info">
  <div class="col-md-6">
    <h5 ><b>البريد الالكتروني</b></h5>
    <p><?php echo e($user->email); ?></p> <!-- </3 :( -->
  </div>
    <div class="col-md-6">
      <h5><b>اسم المستخدم</b></h5>
    <p> <?php echo e($user->username); ?> </p>
  </div>
  </div>
    <div class="row more-info">
        <div class="col-md-6">
            <h5 ><b>رقم التليفون</b></h5>
            <p><?php echo e($user->phone); ?></p> <!-- </3 :( -->
        </div>
        <div class="col-md-6">
            <h5><b> نوع العضوية</b></h5>
            <p><?php echo e($user->member_ship); ?> </p>
        </div>
    </div>
    <div class="row more-info">
        <div class="col-md-6">
            <h5 ><b>التعليم</b></h5>
            <p><?php echo e($user->education); ?></p> <!-- </3 :( -->
        </div>
        <div class="col-md-6">
            <h5><b>البنية</b></h5>
            <p> <?php echo e($user->physique); ?> </p>
        </div>
    </div>
    <div class="row more-info">
        <div class="col-md-6">
            <h5 ><b>الحالة الماديه</b></h5>
            <p><?php echo e($user->financial_status); ?></p> <!-- </3 :( -->
        </div>
        <div class="col-md-6">
            <h5><b>الراتب الحالي</b></h5>
            <p> <?php echo e($user->salary); ?> </p>
        </div>
    </div>

  <div class="row more-info">
  <div class="col-md-6">
    <h5 ><b>الطول</b></h5>
    <p><?php echo e($user->height); ?></p> <!-- </3 :( -->
  </div>
    <div class="col-md-6">
      <h5><b> الوزن </b></h5>
    <p><?php echo e($user->weight); ?> </p>
  </div>
  </div>

  <div class="row more-info">
  <div class="col-md-6">
    <h5 ><b>لون البشرة</b></h5>
    <p><?php echo e($user->skin_color); ?></p> <!-- </3 :( -->
  </div>
      <div class="col-md-6">
          <h5 ><b>النوع</b></h5>
          <p><?php echo e($user->gender); ?></p> <!-- </3 :( -->
      </div>
  </div>
    <div class="row more-info">
        <div class="col-md-6">
            <h5><b> لديك ابناء </b></h5>
            <p><?php echo e($user->children_number); ?> </p>
        </div>
        <div class="col-md-6">
            <h5><b> تاريخ الميلاد</b></h5>
            <p><?php echo e($user->dob); ?></p>
        </div>
    </div>
    <div class="row more-info">
        <div class="col-md-6">
            <h5><b> الحاله الاجتماعيه</b></h5>
            <p><?php echo e($user->social_status); ?> </p>
        </div>
        <?php if($user->social_status == 'married'): ?>
            <div class="col-md-6">
                <h5 ><b>عدد الزوجات</b></h5>
                <p><?php echo e($user->marraige_status); ?></p> <!-- </3 :( -->
            </div>
        <?php endif; ?>
    </div>
    <div class="row more-info">
        <?php if($user->social_status !== 'single'): ?>
            <div class="col-md-6">
                <h5 ><b>عدد الابناء</b></h5>
                <p><?php echo e($user->children_number); ?></p> <!-- </3 :( -->
            </div>
        <?php endif; ?>
        <div class="col-md-6">
            <h5><b> الحاله الصحية</b></h5>
            <p><?php echo e($user->health_details); ?></p>
        </div>
    </div>
    <div class="row more-info">
        <div class="col-md-6">
            <h5 ><b>مجال العمل</b></h5>
            <p><?php echo e($user->career_field); ?></p> <!-- </3 :( -->
        </div>
        <div class="col-md-6">
            <h5><b>الوظيفة</b></h5>
            <p> <?php echo e($user->job); ?> </p>
        </div>
    </div>
    <div class="row more-info">
        <div class="col-md-6">
            <h5><b>التواجد</b></h5>
            <p><?php echo e($user->online); ?> </p>
        </div>
    </div>
  <div class="row more-info">
  <div class="col-md-12">
    <h5 ><b>تحدث عن نفسك </b></h5>
    <p><?php echo e($user->main_description); ?>


  </p> <!-- </3 :( -->
  </div>

  </div>

  <div class="row more-info">
  <div class="col-md-12">
    <h5 ><b> صف الشخص الذي تبحث عنه </b></h5>
    <p><?php echo e($user->other_person_description); ?>


  </p> <!-- </3 :( -->
  </div>

  </div>
  <br/>



  </div>
  <br/><br/>
</div>
        <?php echo $__env->make('visitor.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('visitor.template.endpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>