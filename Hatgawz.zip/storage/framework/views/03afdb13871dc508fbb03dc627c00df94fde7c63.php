<footer class="footer-distributed">
<?php
    $setting = \App\SiteInfo::find(1);
?>
    <div class="footer-left">
        <h3 style="direction: rtl;text-align: right"><?php echo e($setting->site_name); ?></h3>
      <p class="footer-company-about" style="direction: rtl;text-align: right" >
            <?= $setting->footer_about ?>
    </div>
    <div class="footer-center" style="direction: rtl;text-align: center" >
        <div>
            <a href="/client/contact">
            <i class="fa fa-envelope"></i>
            <p>رسائل الادارة</p>
            </a>
        </div>
        <div>
            <a href="/client/nsay7">
                <i class="fa fa-check"></i>
                <p>نصائح واقتراحات</p>
            </a>
        </div>
        <div>
            <a href="/client/faq">
            <i class="fa fa-question"></i>
            <p>الاسئله المتداولة</p>
            </a>
        </div>
    </div>

    <div class="footer-right">
        <a href=".">
        <h3><img src="/public/site_info/<?php echo e($setting->logo); ?>"></h3></a>

    </div>
</footer>
<footer>
    <div class="copy">
        <p>&copy; 2018 All Rights Reserved | Design by <a href="http://gtsaw.com/">gtsaw</a> </p>
    </div>
</footer>
<!--Start of Tawk.to Script-->
<!--<script type="text/javascript">-->
<!--var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();-->
<!--(function(){-->
<!--var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];-->
<!--s1.async=true;-->
<!--s1.src='https://embed.tawk.to/5b33438aeba8cd3125e336ff/default';-->
<!--s1.charset='UTF-8';-->
<!--s1.setAttribute('crossorigin','*');-->
<!--s0.parentNode.insertBefore(s1,s0);-->
<!--})();-->
<!--</script>-->
<!--End of Tawk.to Script-->