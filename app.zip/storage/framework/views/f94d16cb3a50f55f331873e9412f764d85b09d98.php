<!DOCTYPE HTML>
<html>
<head>
<title>هتجوز </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Best Day Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="/visitor/css/bootstrap.css" rel="stylesheet" type="text/css" />

<link href="https://fonts.googleapis.com/css?family=Cairo" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<!--Custom-Theme-files-->
	<link href="/visitor/css/style.css" rel="stylesheet" type="text/css" />
	<script src="/visitor/js/jquery.min.js"> </script>
<!--/script-->
<script type="text/javascript" src="/visitor/js/move-top.js"></script>
<script type="text/javascript" src="/visitor/js/easing.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" ></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
</script>
</head>
<body >
	<!--start-home-->


  <div class="navbar" style="direction: rtl; margin: 0 auto">
  <div class="contaier" style="margin-left:300px">

 
      <ul class="nav navcollaps" style="direction: rtl;">

		  <li><a href=""> <i class="fa fa-users"></i> <?php echo e(Auth::guard('client')->user()->fname . Auth::guard('client')->user()->lname); ?></a></li>
		  <li><a href="<?php echo e(url('/client/logout')); ?>"> Logout</a></li>
          <li><a href="#"><i class="fa fa-comment"></i>    الدردشه</a></li>
          <li><a href="#"><i class="fa fa-envelope"></i>   الرسائل</a></li>
          <li><a href="#"><i class="fa fa-heart"></i>     الاعجاب</a></li>
          <li><a href="#"><i class="fa fa-search"></i>    البحث</a></li>
          <li><a href="#"> <i class="fa fa-home"></i>     الصفحه الرئيسه</a></li>

      </ul>
      
         <div class="navbar-header">
      <button class="toggle"><span></span>
      <span></span>
      <span></span></button>
      <a href="" class="navbar-brand" style="margin-top: -20px"><img src="/visitor/images/logo-girl.png" width="120px"></a>
    </div><!-- navbar-header -->


  </div><!-- contaier -->
</div><!-- navbar -->







	<!-- room -->
	<div class="container" style="direction: rtl">
		<div class="row">
			<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 chat" style="height: 300px">
			<br>
				<h3> <i class="fa fa-user-circle"></i> اهلا وسهلا  </h3>
				<hr>
				
				<div class="col-sm-4 col-xs-4">
				<a href="#">
					<h5>  <i class="fa fa-envelope"></i><br>   رسائل جديدة  </h5>
					</a>
				</div>
				<div class="col-sm-4 col-xs-4">
				<a href="#">
					<h5>  <i class="fa fa-heart"></i> <br>    معجبين جدد </h5>
					</a>
				</div>
				<div class="col-sm-4 col-xs-4">
				<a href="#">
					<h5>  <i class="fa fa-users"></i> <br>   زائرين جدد </h5>
					</a>
				</div>
				<div class="col-sm-12 col-xs-12 chat2 hidden-xs hidden-sm" style="height: 40px">
					<h3>الاعضاء المناسبين</h3>
			
					</div>
				<div class="col-sm-12 col-xs-12 hidden-xs hidden-sm" style="margin-left: 50px;">
					
			
				<div class="col-sm-4 col-xs-4" >
					<img src="/visitor/images/women.png">
				</div>
				<div class="col-sm-4 col-xs-4">
					<img src="/visitor/images/women.png">
				</div>
				<div class="col-sm-4 col-xs-4" >
					<img src="/visitor/images/women.png">
				</div>
					</div>
				
			</div>
			
			<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 search">
					<h3> <i class="fa fa-search"></i>  البحث السريع  </h3>
					<hr>
				
				<h5>   النوع:  <span style="padding-right: 30px"> <input type="radio" name="radio" style="padding: 50px" > انثي   <input type="radio" name="radio"> ذكر </span></h5>
      <hr>
        
         <h5 style="text-align: right;padding-right:130px">
          
           <input type="checkbox" name="checkbox" >
            <i></i>بيانات مع الصور 
            </h5>
            
         <h5  style="text-align: right;padding-right: 130px">
          <br>
           <input type="checkbox" name="checkbox" >
            <i></i>  المتواجدون الآن في الموقع  
            </h5>
            <br>
            <h5  style="text-align: right;padding-right: 130px">
           <input type="checkbox" name="checkbox" >
            <i></i>     زوار الموقع اليوم  
            </h5>
          <hr>
            <form >
    <div class="form-group">
      <select class="form-control" >
        <option>اختر الدولة ... </option>
        <option>مصر</option>
        <option>السعوديه</option>
        <option>الكويت</option>
      </select>
     
    </div>
  </form>
         
             <form>
    <div class="form-group">
      <select class="form-control">
        <option>اختر العمر ... </option>
        <option>20</option>
        <option>30</option>
        <option>30</option>
      </select>
     
    </div>
  </form>
         
         <hr>
    
        
<button  class="login"> <i class="fa fa-search"></i> ابحث </button>
				
			</div>
		</div>
	</div>
	
	
	
	<!-- room -->
<div class="container">
	
<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 main">
	<h4>هناك أحاديث لا نريد لها نهاية، لا يهم فيها ما يقال بل مع من نقوله. جد من يغنيك عن الجميع
</h4>
</div>
</div>
<div class="clearfix"></div>

<!-- room -->
	<div class="container" style="direction: rtl">
		<div class="row">
			<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 chat">
				<h3> <i class="fa fa-comments"></i> غرف الدرشه  </h3>
				<hr>
				<h4>متواجد حاليا (15) </h4>
				<hr>
				<div class="col-sm-6 col-xs-6">
				<a href="#">
					<h5>  <i class="fa fa-comments"></i>   دردشة زواج </h5>
					</a>
				</div>
				<div class="col-sm-6 col-xs-6">
				<a href="#">
					<h5>  <i class="fa fa-comments"></i>   دردشة عامة </h5>
					</a>
				</div>
				<br>
				<br>
				<br>
				<div class="col-sm-6 col-xs-6">
				<a href="#">
					<h5>  <i class="fa fa-comments"></i>   دردشة تعارف </h5>
					</a>
				</div>
				<div class="col-sm-6 col-xs-6">
				<a href="#">
					<h5>  <i class="fa fa-comments"></i>   دردشة تواصل </h5>
					</a>
				</div>
				
				
			</div>
			
			<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 search hidden-xs hidden-sm" style="height: 600px">
					<h3> كبار الشخصيات   </h3>
					<hr>
					<div class="col-sm-12 col-xs-12 hidden-xs hidden-sm" style="margin-left: 50px;">
					
			
				<div class="col-sm-4 col-xs-4" >
				<a href="#">
					<img src="/visitor/images/man.png">
					</a>
				</div>
				<div class="col-sm-4 col-xs-4">
					<a href="#">
					<img src="/visitor/images/man.png">
					</a>
				</div>
				<div class="col-sm-4 col-xs-4" >
					<a href="#">
					<img src="/visitor/images/man.png">
					</a>
				</div>
					</div>
					
					
				
				<h3>  الاعضاء الجدد   </h3>
					<hr>
					<div class="col-sm-12 col-xs-12" style="margin-left: 50px;">
					
			
				<div class="col-sm-4 col-xs-4" >
				<a href="#">
					<img src="/visitor/images/man.png">
					</a>
				</div>
				<div class="col-sm-4 col-xs-4">
					<a href="#">
					<img src="/visitor/images/man.png">
					</a>
				</div>
				<div class="col-sm-4 col-xs-4" >
					<a href="#">
					<img src="/visitor/images/man.png">
					</a>
				</div>
					</div>
			</div>
			
			
		</div>
	</div>
	
	
	
	<!-- room -->
	
	
	
	
	
	<!--/footer-->
	 
	 
		<footer class="footer-distributed">

			<div class="footer-left">
					<p class="footer-company-about" style="direction: rtl;text-align: right" >
					<span style="direction: rtl"> هتجوز </span>
موقع تعارف وتواصل عريق يضع الوطن العربي والعالم بين يديك من خلال الدردشة والمراسلة والمحادثة والشات للقاء شريك العمر والارتباط بالنصف الآخر و فارس الأحلام. 				</p>

				


				
			</div>

			<div class="footer-center" style="direction: rtl;text-align: center" >
					<div>
					<i class="fa fa-envelope"></i>
					<p>رسائل الادارة</p>
				</div>

				<div>
					<i class="fa fa-check"></i>
					<p>نصائح واقتراحات</p>
				</div>

				<div>
					<i class="fa fa-question"></i>
					<p>الاسئله المتداولة</p>
				</div>

			

			</div>

			<div class="footer-right">
<h3><img src="/visitor/images/logo-man.png"></h3>

			</div>

		</footer>

	 
	 
	 
	 
	 
		 
<footer>
		<div class="copy">
		    <p>&copy; 2018 All Rights Reserved | Design by <a href="http://gtsaw.com/">gtsaw</a> </p>
		</div>
		</footer>
		<!--//footer-->
			



<script>
	
	$(".toggle").click(function(){
  $(".navcollaps").toggleClass("show");
});
	</script>

	
			
										
						
								
								
								


</body>
</html>