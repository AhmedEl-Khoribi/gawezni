<?php $__env->startSection('content'); ?>
<?php if($flash = session('message')): ?>
<div class="alert success">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
    <b><?php echo e($flash); ?></b>
</div>
<?php endif; ?>
<?php if($flash = session('deleted')): ?>
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
    <b><?php echo e($flash); ?></b>
</div>
<?php endif; ?>

<div class="box">
            <div class="box-header">
  <h3 class="box-title">Data Table For Site Information</h3>
</div>
    <div class="box-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
        <tr>
          <th>ID</th>
          <th>Site Name</th>
          <th>Logo</th>
          <th>Fivicon</th>
          <th>Key Words</th>
          <th>Description</th>
          <th>Author</th>
          <th>Kasam</th>
          <th>Policy</th>
          <th>Website Use</th>
          <th>Payment Methods</th>
          <th>Footer About Us</th>
          <th>Social Accounts</th>
          <th>Edit / Delete</th>
        </tr>
        </thead>
        <tbody>
<?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($info->id); ?></td>
          <td><?php echo e($info->site_name); ?></td>
          <td><img src="/public/site_info/<?php echo e($info->logo); ?>" width="70"></td>
          <td><img src="/public/site_info/<?php echo e($info->fivicon); ?>" width="90"></td>
          <td><?php echo e($info->key_words); ?></td>
          <td><?php echo e($info->description); ?></td>
          <td><?php echo e($info->author); ?></td>
          <td><?php echo e($info->term_docx); ?></td>
          <td><?php echo e($info->policy); ?></td>
          <td><?php echo e($info->website_used); ?></td>
          <td><?php echo e($info->payment_methods); ?></td>
          <td><?php echo e($info->footer_about); ?></td>
          <td>
              <a href="<?php echo e($info->fb); ?>" class="btn btn-social-icon btn-facebook"><i class="fa fa-facebook"></i></a>
              <br>
              <a href="<?php echo e($info->tw); ?>" class="btn btn-social-icon btn-twitter"><i class="fa fa-twitter"></i></a>
              <br>
              <a href="<?php echo e($info->instagram); ?>" class="btn btn-social-icon btn-instagram"><i class="fa fa-instagram"></i></a>
              <br>
              <a href="<?php echo e($info->google); ?>" class="btn btn-social-icon btn-google"><i class="fa fa-google-plus"></i></a>
          </td>
          <td>
            <a href="/admin/edit_info/<?php echo e($info->id); ?>" class="btn btn-app">
                 <i class="fa fa-edit"></i> Edit
            </a>
          </td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>

          <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>