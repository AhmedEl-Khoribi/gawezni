<?php $__env->startSection('content'); ?>
<?php
  $do = (isset($_GET['do'])) ? $_GET['do'] : 'blocked' ;
?>
              <center>
                <a href="/admin/users?do=blocked"><button class="btn btn-link">Not-Approved/Blocked Users</button></a> || <a href="/admin/users?do=approved"><button class="btn btn-link">Approved Users</button></a>
              </center>
<?php if($flash = session('message')): ?>
<div class="alert success">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
    <b><?php echo e($flash); ?></b>
</div>
<?php endif; ?>
<?php if($flash = session('deleted')): ?>
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
    <b><?php echo e($flash); ?></b>
</div>
<?php endif; ?>
 <?php if($do === 'blocked'): ?>
 <div class="box">
            <div class="box-header">
  <h3 class="box-title">Data Table For Not Approved Users</h3>
</div>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Approved / Not Approved</th>
                  <th>Edit / Delete / Message</th>
                  <th>View Details</th>
                </tr>
                </thead>
                <tbody>
<?php $__currentLoopData = $not_approved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($userz->id); ?></td>
                  <td><?php echo e($userz->username); ?></td>
                  <td><?php echo e($userz->email); ?></td>
                  <td>
                    <a href="/admin/approve/<?php echo e($userz->id); ?>">
                      <button type="button" class="btn bg-navy btn-flat margin">Approve User</button>
                    </a>
                  </td>
                  <td>
                    <a href="/admin/edit_user/<?php echo e($userz->id); ?>" class="btn btn-app">
                         <i class="fa fa-edit"></i> Edit
                    </a>
                    <a href="/admin/delete/<?php echo e($userz->id); ?>" class="btn btn-app">
                         <i class="fa fa-close"></i> Delete
                    </a>
                    <a href="/admin/send_message/<?php echo e($userz->id); ?>" class="btn btn-app">
                      <i class="fa fa-envelope"></i> Message
                    </a>
                  </td>
                  <td>
                  <a href="/admin/details/<?php echo e($userz->id); ?>">
                    <button type="button" class="btn btn-default btn-block">View User Details</button>
                  </a>
                  </td>
                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
<?php endif; ?>
 <?php if($do === 'approved'): ?>
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Table For Approved Users</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Approved / Not Approved</th>
                  <th>Membership</th>
                  <th>Edits / Deletes</th>
                  <th>View Details</th>
                </tr>
                </thead>
                <tbody>
<?php $__currentLoopData = $approved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($user->id); ?></td>
                  <td><?php echo e($user->username); ?></td>
                  <td><?php echo e($user->email); ?></td>
                  <td>
                    <a href="/admin/unapprove/<?php echo e($user->id); ?>">
                      <button type="button" class="btn bg-purple btn-flat margin">Block User</button>
                    </a>
                  </td>
                  <td>
                    <?php if($user->member_ship == 'free'): ?>
                      <a href="/admin/upgrage/<?php echo e($user->id); ?>">
                        <button type="button" class="btn bg-purple btn-flat margin">upgrade</button>
                      </a>
                    <?php else: ?>
                       Premium
                    <?php endif; ?>
                  </td>
                  <td>
                    <a href="/admin/edit_user/<?php echo e($user->id); ?>" class="btn btn-app">
                         <i class="fa fa-edit"></i> Edit
                    </a>
                    <a href="/admin/delete/<?php echo e($user->id); ?>" class="btn btn-app">
                         <i class="fa fa-close"></i> Delete
                    </a>
                    <a href="/admin/send_message/<?php echo e($user->id); ?>" class="btn btn-app">
                      <i class="fa fa-envelope"></i> Inbox
                    </a>
                  </td>
                  <td>
                  <a href="/admin/details/<?php echo e($user->id); ?>">
                    <button type="button" class="btn btn-block btn-dnager">View User Details</button>
                  </a>
                  </td>
                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>