<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-ban"></i> Error!</h4>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p>* <?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(Session::has('message')): ?>
            <!-- Modal -->
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-check"></i> Successful</h4>
                    <?php if(Session::has('message')): ?>
                        <p><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if(isset($country)): ?>
                <form action="<?php echo e(route('country.update',$country->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <div class="box box-danger">
                        <div class="box-header">
                            <h3 class="box-title">Edit Country : <?php echo e($country->name); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <label>Country Name</label>
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-pencil"></i>
                                    </div>
                                    <input type="text" class="form-control" name="name" value="<?php echo e($country->name); ?>" placeholder="Country Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>currency</label>
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-money"></i>
                                    </div>
                                    <input type="text" class="form-control" name="currency" value="<?php echo e($country->currency); ?>" placeholder="Currancy">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <button type="submit" class="btn btn-block btn-primary btn-lg">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="content-wrapper" style="margin-left:0">
                    <!-- Content Header (Page header) -->
                    <!-- Main content -->
                    <section class="content">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="box">
                                    <div class="box-header">
                                        <h3 class="box-title">Data Table With Full Features</h3>
                                    </div>
                                    <!-- /.box-header -->
                                    <div class="box-body">
                                        <table id="example1" class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>City Name</th>
                                                    <th>Date</th>
                                                    <th>Control</th>
                                                </tr>
                                            </thead>
                                            <?php
                                            $i=1;
                                            ?>
                                            <?php $__currentLoopData = $country->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($city->name); ?></td>
                                                    <td><?php echo e($city->created_at); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('admin/city/'. $country->id . '/edit')); ?>"  class="btn btn-success"><i class="fa fa-edit"> Edit</i></a>
                                                        <form action="<?php echo e(url('admin/city/'. $country->id)); ?>" method="post" style="display: inline;">
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php echo e(method_field('DELETE')); ?>

                                                            <button type="submit" class="btn btn-danger"> <i class="fa fa-remove">X</i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                    <!-- /.box-body -->
                                </div>
                                <!-- /.box -->
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </section>
                        <!-- /.content -->
                    </div>
            <?php endif; ?>
            <?php if(isset($countryCity)): ?>

                <form action="<?php echo e(route('city.update',$countryCity->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <div class="box box-danger">
                        <div class="box-header">
                            <h3 class="box-title">Edit City : <?php echo e($countryCity->name); ?></h3>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <label>City Name</label>
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-pencil"></i>
                                    </div>
                                    <input type="text" class="form-control" name="name" value="<?php echo e($countryCity->name); ?>" placeholder="City Name">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Choose Country</label>
                                <select class="form-control" name="country_id">
                                    <option  value="">Please Choose Country</option>
                                    <?php $__currentLoopData = $cntry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>" <?php if($countryCity->id == $country->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($country->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <div cl    ass="input-group">
                                    <button type="submit" class="btn btn-block btn-primary btn-lg">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>