
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> Error!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>* <?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <?php if(Session::has('message')): ?>
        <!-- Modal -->
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-check"></i> Successful</h4>
            <?php if(Session::has('message')): ?>
                <p><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <?php if(isset($counteryCity)): ?>
        <div class="content-wrapper" style="margin-left:0">
            <!-- Content Header (Page header) -->
            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Data Table With Full Features</h3>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Countery Name</th>
                                        <th>Currency</th>
                                        <th>Cities Names</th>
                                        <th>Date</th>
                                        <th>Control</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $i=1;
                                    ?>
                                    <?php $__currentLoopData = $counteryCity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $cities = $country->cities;
                                        $cityName = '';
                                        foreach($cities as $city)
                                        {
                                            $cityName .= $city->name . ' , ';
                                        }
                                        $cityName = trim($cityName,' , ');
                                        ?>
                                        <tr>
                                            <td><?php echo e($country->id); ?></td>
                                            <td><?php echo e($country->name); ?></td>
                                            <td><?php echo e($country->currency); ?></td>
                                            <td><?php echo e($cityName); ?></td>
                                            <td><?php echo e($country->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('admin/country/'. $country->id . '/edit')); ?>" class="btn btn-success"><i class="fa fa-edit"> Edit</i></a>
                                                <a>
                                                    <form action="<?php echo e(url('admin/country/'.$country->id)); ?>" method="post" style="display: inline;">
                                                        <?php echo e(csrf_field()); ?>

                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <button type="submit" class="btn btn-danger"> <i class="fa fa-remove"></i></button>
                                                    </form>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>

    <?php endif; ?>
    <?php if(isset($chats)): ?>
        <div class="content-wrapper" style="margin-left:0;">
            <!-- Content Header (Page header) -->
            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">All Client Messages</h3>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Sender Name</th>
                                            <th>Sends Message Count</th>
                                            <th>recived Message Count</th>
                                            <th>Sending At</th>
                                            <th>view Client Chats</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $i=1;
                                    ?>
                                    <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e(\App\Client::find($chat->sender_id)->fname); ?></td>
                                            <td><?php echo e(\App\Mail::where('sender_id',$chat->sender_id)->count()); ?></td>
                                            <td><?php echo e(\App\Mail::where('receiver_id',$chat->sender_id)->count()); ?></td>
                                            <td><?php echo e(\App\Client::find($chat->sender_id)->created_at); ?></td>
                                            <td><a href="mail/<?php echo e($chat->sender_id); ?>/edit"> Show </a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td></td>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>

    <?php endif; ?>
    <?php if(isset($clientChat)): ?>
        <div class="col-md-12">
                <!-- DIRECT CHAT -->
                <div class="box box-warning direct-chat direct-chat-warning">
                    <div class="box-header with-border">
                        <h3 class="box-title">Chats To <?php echo e(\App\Client::find($clientChat[0]->sender_id)->fname . ' ' . \App\Client::find($clientChat[0]->sender_id)->lname); ?></h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="Contacts"
                                    data-widget="chat-pane-toggle">
                                <i class="fa fa-comments"></i></button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="direct-chat-messages">
                            <?php
                            $i=1;
                            ?>
                            <?php $__currentLoopData = $clientChat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $var = explode('/',parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH ))[3];
                                    ?>
                                <?php if($chat->sender_id == $var): ?>
                                    <div class="direct-chat-msg">
                                        <div class="direct-chat-info clearfix">
                                            <span class="direct-chat-name pull-right"><?php echo e(\App\Client::find($chat->sender_id)->fname . ' ' . \App\Client::find($chat->sender_id)->lname); ?></span>
                                            <span class="direct-chat-timestamp pull-left"><?php echo e($chat->created_at); ?></span>
                                        </div>
                                        <img class="direct-chat-img" src="<?php echo e(asset('files/users/'.\App\Client::find($chat->sender_id)->image )); ?>" alt="message user image">
                                        <div class="direct-chat-text">
                                            <?php echo e($chat->body); ?>

                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="direct-chat-msg right">
                                        <div class="direct-chat-info clearfix">
                                            <span class="direct-chat-name pull-right"><?php echo e(\App\Client::find($chat->sender_id)->fname . ' ' . \App\Client::find($chat->sender_id)->lname); ?></span>
                                            <span class="direct-chat-timestamp pull-left"><?php echo e($chat->created_at); ?></span>
                                        </div>
                                        <img class="direct-chat-img" src="<?php echo e(asset('files/users/'.\App\Client::find($chat->sender_id)->image )); ?>" alt="message user image">
                                        <div class="direct-chat-text">
                                            <?php echo e($chat->body); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!--/.direct-chat-messages-->

                        <!-- /.direct-chat-pane -->
                    </div>














                </div>
                <!--/.direct-chat -->
            </div>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>