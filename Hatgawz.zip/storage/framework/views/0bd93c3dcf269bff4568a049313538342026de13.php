<div class="navbar" style="direction: rtl; margin: 0 auto">
    <div class="contaier" style="margin-left:300px">
        <ul class="nav navcollaps" style="direction: rtl;">
  <ul class="nav navcollaps" style="direction: rtl;">
        <?php if(Auth::guard('client')->check()): ?>
          <li><a href="/client/home"> <i class="fa fa-users"></i> <?php echo e(Auth::guard('client')->user()->fname . Auth::guard('client')->user()->lname); ?></a></li>
            <li><a href="<?php echo e(url('/client/logout')); ?>"><i class="fa fa-comment"></i>الخروج</a></li>
             <li><a href="<?php echo e(url('/client/message')); ?>"><i class="fa fa-envelope"></i>   الرسائل</a></li>
            <li><a href="<?php echo e(url('liked')); ?>"><i class="fa fa-heart"></i>     الاعجاب</a></li>

      <?php endif; ?>
            <li><a href="#"><i class="fa fa-comment"></i>    الدردشه</a></li>
            <li><a href="/client/visits"> <i class="fa fa-users"></i>    الزيارات</a></li>
            <li><a href="#"><i class="fa fa-search"></i>    البحث</a></li>
            <li><a href="/"> <i class="fa fa-home"></i>     الصفحه الرئيسه</a></li>
        </ul>

        <div class="navbar-header">
            <button class="toggle"><span></span>
                <span></span>
                <span></span></button>
            <a href="" class="navbar-brand" style="margin-top: -20px"><img src="/visitor/images/logo-girl.png" width="120px"></a>
        </div><!-- navbar-header -->


    </div><!-- contaier -->
</div><!-- navbar -->